class OGException(Exception):
    """A simple exception for the EE library."""
    pass
