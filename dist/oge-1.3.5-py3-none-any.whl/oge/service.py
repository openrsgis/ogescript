from oge import ApiFunction

from . import collections
from . import collection
from . import element
from . import coverageCollection
from . import coverage
from . import featurecollection
from . import feature
from . import apifunction
from . import process
from . import processes


class Service(element.Element):
    # 类变量
    _url = "http://localhost"

    def __init__(self):
        # self.initialize(url=self.url)
        super(Service, self).__init__(None, None, None)

    @staticmethod
    def process(process_id):
        api_function = ApiFunction.lookup(process_id)
        return process.Process(api_function)

    @staticmethod
    def collections(datetime="", bbox=None, bbox_crs="WGS84"):
        if bbox is None:
            bbox = [-180, -90, 180, 90]
        params = {
            'datetime': datetime,
            'bbox': bbox,
            'bbox_crs': bbox_crs
        }
        return collections.Collections(params)

    """
    查询符合条件的数据集
    """

    def getCollections(self, datetime="null", bbox="null", bbox_crs="WGS84"):
        params = {
            'baseUrl': self._url,
            'datetime': datetime,
            'bbox': bbox,
            'bboxCrs': bbox_crs,
        }
        return collections.Collections(params)

    """
    查询指定Id的数据集
    """

    def getCollection(self, collectionId):
        params = {
            'baseUrl': self._url,
            'collectionId': collectionId,
        }
        return collection.Collection(params)

    """
    查询指定Id的要素数据集
    """

    def getFeatureCollection(self, collectionId, datetime="null", bbox="null", bbox_crs="WGS84", filters="null"):
        param = {
            'baseUrl': self._url,
            'collectionId': collectionId,
            'datetime': datetime,
            'bbox': bbox,
            'bboxCrs': bbox_crs,
            'filter': filters
        }
        return featurecollection.FeatureCollection(param)

    """
    查询指定Id的要素
    """

    def getFeature(self, collectionId, featureId):
        param = {
            'baseUrl': self._url,
            'collectionId': collectionId,
            'featureId': featureId
        }
        return feature.Feature(None, None, param)

    """
    查询指定Id的覆盖数据集
    """

    def getCoverageCollection(self, collectionId, datetime="null", bbox="null", bbox_crs="WGS84"):
        param = {
            'baseUrl': self._url,
            'collectionId': collectionId,
            'datetime': datetime,
            'bbox': bbox,
            'bboxCrs': bbox_crs,
        }
        return coverageCollection.CoverageCollection(param)

    """
    查询指定Id的覆盖数据
    """

    def getCoverage(self, collectionId, coverageId):
        param = {
            'baseUrl': self._url,
            'collectionId': collectionId,
            'coverageId': coverageId
        }
        return coverage.Coverage(param)

    """
    查询处理列表
    """

    def getProcesses(self):
        return processes.Processes(self._url)

    """
    查询特定id的处理
    """

    def getProcess(self, process_id):
        param = {
            "baseUrl": self._url,
            "processId": process_id
        }
        return process.Process(param)

    @classmethod
    def initialize(cls, url="http://localhost"):
        """Imports API functions to this class."""
        cls._url = url
        if not cls._initialized:
            apifunction.ApiFunction.importApi(cls, 'Service', 'Service')
            cls._initialized = True
        return Service()

    @classmethod
    def getUrl(cls):
        return cls._url

    @staticmethod
    def name():
        return 'Service'
