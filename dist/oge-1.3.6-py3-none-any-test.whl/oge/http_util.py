# import requests
import oge.mapclient
import json
from pyodide.http import pyfetch
import asyncio


class HTTPUtil:

    @staticmethod
    def postRequest(url, param):
        res = requests.post(url=url, data=param)
        return res.text

    @staticmethod
    def getRequest(url, param):
        res = requests.get(url=url, data=param)
        return res.text

    @staticmethod
    def postDagJson(dagJson):
        params = {"dag": dagJson}
        space_params = oge.mapclient.getSpaceParams()
        print("spaceParams:", space_params)
        if space_params is not None:
            params["spaceParams"] = space_params
        # res = HTTPUtil.postRequest("http://localhost:8085/oge-dag/saveDagJson", json.dumps(params))

        async def get_data(dag):
            # response = await pyfetch('http://125.220.153.26:8085/oge-dag/saveDagJson', method="POST", body=dag)
            response = await pyfetch('http://oge.whu.edu.cn/api/oge-dag/saveDagJson', method="POST", body=json.dumps(params))
            res = await response.string()
        #     print(res)
        task = [get_data(dagJson)]
        loops = asyncio.get_event_loop()
        loops.run_until_complete(asyncio.wait(task))
