import requests


class HTTPUtil:

    @staticmethod
    def postRequest(url, param):
        res = requests.post(url=url, data=param)
        return res.text

    @staticmethod
    def getRequest(url, param):
        res = requests.get(url=url, data=param)
        return res.text
